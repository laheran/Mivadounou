package mivadounou.projet2.uut.ucao.mivadounou.adapters;

import android.content.Context;
import android.content.Intent;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentTransaction;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.CardView;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ImageView;
import android.widget.TextView;

import java.util.List;

import mivadounou.projet2.uut.ucao.mivadounou.activities.MainActivity;
import mivadounou.projet2.uut.ucao.mivadounou.entities.Person;
import mivadounou.projet2.uut.ucao.mivadounou.R;
import mivadounou.projet2.uut.ucao.mivadounou.fragments.BelugaFragment;
import mivadounou.projet2.uut.ucao.mivadounou.fragments.CommandeFragment;
import mivadounou.projet2.uut.ucao.mivadounou.fragments.LocationFragment;
import mivadounou.projet2.uut.ucao.mivadounou.fragments.RechercheFragment;

/**
 * Created by LAHERAN on 05/04/2017.
 */
public class RVAdapter extends RecyclerView.Adapter<RVAdapter.ViewHolder> {

    private OnItemClickListener listener;
    List<Person> persons;

    public RVAdapter(List<Person> persons){

        this.persons = persons;
    }

    public static class ViewHolder extends RecyclerView.ViewHolder implements View.OnClickListener{
        CardView cardView;
        TextView personName;
        ImageView personPhoto;
        private OnItemClickListener listener;

//        private long PERSONId;
//
//        public PersonViewHolderClickListener clickListener;


        ViewHolder(View itemView ) {
            super(itemView);
            cardView = (CardView)itemView.findViewById(R.id.card_view);
            personName = (TextView)itemView.findViewById(R.id.person_name);
            personPhoto = (ImageView)itemView.findViewById(R.id.person_photo);

//            this.clickListener = cliclklistener;
            itemView.setClickable(true);
            itemView.setOnClickListener(this);

//            cardView.setOnClickListener(new View.OnClickListener() {
//                @Override
//                public void onClick(View view) {
//                    AppCompatActivity activity = (AppCompatActivity) view.getContext();
//                    Fragment myFragment = new BelugaFragment();
//                    activity.getSupportFragmentManager().beginTransaction().replace(R.id.content, myFragment).addToBackStack(null).commit();
//
//                }
//            });
        }

        @Override
        public void onClick(View v) {
            int position = getAdapterPosition();
            switch (position) {
                case 0:
                    AppCompatActivity activity = (AppCompatActivity) v.getContext();
                    Fragment myFragment = new BelugaFragment();
                    activity.getSupportFragmentManager().beginTransaction().replace(R.id.content, myFragment).addToBackStack(null).commit();
                    break;

                case 1:
                    AppCompatActivity aloc = (AppCompatActivity) v.getContext();
                    Fragment loc = new LocationFragment();
                    aloc.getSupportFragmentManager().beginTransaction().replace(R.id.content, loc).addToBackStack(null).commit();
                    break;

                case 2:
                    AppCompatActivity acm = (AppCompatActivity) v.getContext();
                    Fragment cm = new CommandeFragment();
                    acm.getSupportFragmentManager().beginTransaction().replace(R.id.content, cm).addToBackStack(null).commit();
                    break;
                default:
                    AppCompatActivity activityd = (AppCompatActivity) v.getContext();
                    Fragment rech = new RechercheFragment();
                    activityd.getSupportFragmentManager().beginTransaction().replace(R.id.content, rech).addToBackStack(null).commit();
                    break;
            }

//            clickListener.onItemClick(PERSONId);
        }

        public void setOnItemClickListener(OnItemClickListener listener){
            this.listener = listener;
        }


    }




//    @Override
//    public ViewHolder onCreateViewHolder(final ViewGroup viewGroup, int i) {
//        View v = LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.cards_main, viewGroup, false);
//        ViewHolder pvh = new ViewHolder(v, new PersonViewHolderClickListener() {
//            @Override
//            public void onItemClick(long id) {
//                AppCompatActivity activity = (AppCompatActivity) viewGroup.getContext();
//                    Fragment myFragment = new BelugaFragment();
//                    activity.getSupportFragmentManager().beginTransaction().replace(R.id.content, myFragment).addToBackStack(null).commit();
//
//            }
//        });
//        return pvh;
//    }

    @Override
    public RVAdapter.ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.cards_main, parent, false);
        return new ViewHolder(v);
    }


    @Override
    public void onBindViewHolder(ViewHolder viewHolder, int i) {
        viewHolder.personName.setText(persons.get(i).getName());
        viewHolder.personPhoto.setImageResource(persons.get(i).getPhotoId());
        viewHolder.setOnItemClickListener(listener);
//        viewHolder.PERSONId = i;

    }

    @Override
    public void onAttachedToRecyclerView(RecyclerView recyclerView) {
        super.onAttachedToRecyclerView(recyclerView);
    }

    @Override
    public int getItemCount() {
        return persons.size();
    }


    public interface OnItemClickListener{
        public void onItemClick(String textName);
    }
    public void setOnItemClickListener(OnItemClickListener listener){
        this.listener = listener;
    }

//    public interface PersonViewHolderClickListener {
//
//        void onItemClick(long id);
//    }


}
